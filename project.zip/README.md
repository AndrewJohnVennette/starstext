# starstext
